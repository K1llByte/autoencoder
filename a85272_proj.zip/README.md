# Technologies and Applications

## Running

```
python src/main.py
```

## Overview

## Project Structure

Each neural network model we devoleped and tested will be packed in a module
to be reused by the classifier notebook (or other).

- `data/` - All image data including the target `/` dataset and some images
for quick testing

- `models` - Saved Models to reuse

- `src/` - Contains all scripts and notebooks